# WEB3studentopvolging
 Opdracht WEB 3 voor de evaluatie

## Gebruik van de applicatie studentenopvolging
1. Mysql workbench geïnstalleerd staan
2. Bij alle folders: backend, student, lector, admin: npm install
3. Initialiseren databank (Prisma)

### Initialiseren databank (Prisma)
1. Nadat we bij onze server/backend nmp install hebben gedaan, zouden we in de folder van backend: $ npx prisma migrate dev --name init
2. Dit zou de tabellen moeten aanmaken in mysql

