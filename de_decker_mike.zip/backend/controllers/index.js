exports.StudentController = require("./student_controller");
exports.GroepController = require("./groep_controller");
exports.OpdrachtController = require("./opdracht_controller");
exports.RapportController = require("./rapport_controller");
exports.OpdrachtElementController = require("./opdracht_element_controller");
exports.UploadController = require("./uploadOpdrachtCsv_controller");
