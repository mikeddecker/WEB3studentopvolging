const GroepController = {
  create: () => {},
  read: () => {},
  update: () => {},
  delete: () => {},
};

module.exports = GroepController;
