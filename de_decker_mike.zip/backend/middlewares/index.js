const authMiddleware = require("./authMiddleware");

exports.authMiddleware = authMiddleware;
