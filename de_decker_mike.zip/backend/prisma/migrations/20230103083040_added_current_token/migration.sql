-- AlterTable
ALTER TABLE `student` ADD COLUMN `currentToken` VARCHAR(64) NULL,
    ADD COLUMN `tokenInsertDate` DATETIME NULL;
