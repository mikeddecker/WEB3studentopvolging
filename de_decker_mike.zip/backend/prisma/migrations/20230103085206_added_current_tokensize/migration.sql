/*
  Warnings:

  - You are about to alter the column `tokenInsertDate` on the `student` table. The data in that column could be lost. The data in that column will be cast from `DateTime(0)` to `DateTime`.

*/
-- AlterTable
ALTER TABLE `student` MODIFY `currentToken` VARCHAR(500) NULL,
    MODIFY `tokenInsertDate` DATETIME NULL;
