/*
  Warnings:

  - You are about to drop the column `currentToken` on the `student` table. All the data in the column will be lost.
  - You are about to drop the column `tokenInsertDate` on the `student` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `opdrachtelement` ADD COLUMN `kahootActief` BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE `student` DROP COLUMN `currentToken`,
    DROP COLUMN `tokenInsertDate`;
